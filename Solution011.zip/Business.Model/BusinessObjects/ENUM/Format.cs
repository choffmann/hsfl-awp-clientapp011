﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace De.HsFlensburg.ClientApp011.Business.Model.BusinessObjects.ENUM
{
    public enum Format
    {
        Ebook,
        Taschenbuch,
        HardCover
    }
}
